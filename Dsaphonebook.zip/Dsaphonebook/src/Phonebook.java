import javax.swing.*;
import java.awt.*;
import javax.swing.table.DefaultTableModel;
import java.awt.event.ActionEvent;
import java.awt.event.ActionListener;
import java.io.*;
import java.util.ArrayList;

public class Phonebook extends JFrame {
    private ArrayList<String[]> contacts = new ArrayList<>();  // Stores contacts
    private JButton switchToContactsButton;
    private JButton contactsButton;
    private JButton addButton;
    private JFormattedTextField addressfeild;
    private JFormattedTextField phonenumberfeild;
    private JFormattedTextField lastnamefield;
    private JFormattedTextField firstnamefeild;
    private JPanel PhonebookPanel;
    private JFrame frame;

    private final String FILE_NAME = "contacts.txt";  // File to store contacts

    public Phonebook() {
        // Load contacts from the file when the application starts
        loadContactsFromFile();

        // Event listener for switching to contact display form
        contactsButton.addActionListener(new ActionListener() {
            @Override
            public void actionPerformed(ActionEvent e) {
                // Open the Contact form and pass the contacts array
                Contact contactForm = new Contact(contacts);
                contactForm.setVisible(true);  // Display the contact form
                dispose();  // Close the current Phonebook form
            }
        });

        // Add contact to the list and write it to the file
        addButton.addActionListener(new ActionListener() {
            @Override
            public void actionPerformed(ActionEvent e) {
                String firstName = firstnamefeild.getText();
                String lastName = lastnamefield.getText();
                String phoneNumber = phonenumberfeild.getText();
                String address = addressfeild.getText();

                // Create a new contact entry and add it to the contacts list
                String[] contact = {firstName, lastName, phoneNumber, address};
                contacts.add(contact);

                // Write the contact to the file
                writeContactToFile(contact);

                // Clear the input fields after adding
                firstnamefeild.setText("");
                lastnamefield.setText("");
                phonenumberfeild.setText("");
                addressfeild.setText("");

                JOptionPane.showMessageDialog(PhonebookPanel, "Contact added! 👍");
            }
        });
    }

    // Method to write a contact to the file
    private void writeContactToFile(String[] contact) {
        try (BufferedWriter writer = new BufferedWriter(new FileWriter(FILE_NAME, true))) {
            writer.write(contact[0] + "," + contact[1] + "," + contact[2] + "," + contact[3]);
            writer.newLine();
        } catch (IOException e) {
            e.printStackTrace();
        }
    }

    // Method to load contacts from the file
    private void loadContactsFromFile() {
        try (BufferedReader reader = new BufferedReader(new FileReader(FILE_NAME))) {
            String line;
            while ((line = reader.readLine()) != null) {
                String[] contact = line.split(",");  // Split the line by commas
                if (contact.length == 4) {  // Ensure there are four fields
                    contacts.add(contact);  // Add the contact to the list
                }
            }
        } catch (IOException e) {
            e.printStackTrace();
        }
    }

    public static void main(String[] args) {
        Phonebook phone = new Phonebook();
        phone.setContentPane(phone.PhonebookPanel);
        phone.setTitle("Phone book");
        phone.setSize(700, 600);
        phone.setVisible(true);
        phone.setDefaultCloseOperation(JFrame.EXIT_ON_CLOSE);
    }

    public JPanel PhonebookPanel(){
        return PhonebookPanel;
    }
}
