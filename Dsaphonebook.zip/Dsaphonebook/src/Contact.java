import javax.swing.*;
import javax.swing.table.DefaultTableModel;
import java.awt.*;
import java.awt.event.ActionEvent;
import java.awt.event.ActionListener;
import java.io.*;
import java.util.ArrayList;
import java.util.Collections;
import java.util.Comparator;

public class Contact extends JFrame {
    private ArrayList<String[]> contacts;
    private DefaultTableModel tableModel;
    private JButton sortAscButton;
    private JButton sortDscButton;
    private JButton deleteButton;
    private JButton addButton;
    private JTextField searchField;
    private JButton searchButton;
    private JTable Contacts;
    private JPanel Contactpanel;
    private JTable contactsTable;
    private final JPanel contactPanel;
    private static JPanel contentPane;
    private static final String FILE_NAME = "contacts.txt";
    private JButton displayButton;
    private JFrame frame;

    public Contact(ArrayList<String[]> contacts) {
        this.contacts = contacts;
        setTitle("Contacts");
        setSize(600, 400);
        setDefaultCloseOperation(JFrame.DISPOSE_ON_CLOSE);

        // Initialize components
        contactPanel = new JPanel(new BorderLayout());  // Set layout manager
        JPanel buttonPanel = new JPanel();  // Panel for buttons and search bar
        JPanel searcpanel = new JPanel();

        // Initialize buttons and search field
        sortAscButton = new JButton("Sort Ascending");
        sortDscButton = new JButton("Sort Descending");
        deleteButton = new JButton("Delete Contact");
        addButton = new JButton("Add Contact");
        searchField = new JTextField(20);  // Search field with a width of 20 columns
        searchButton = new JButton("Search");
         displayButton = new JButton("Display");


        // Add components to button panel
        buttonPanel.add(sortAscButton);
        buttonPanel.add(sortDscButton);
        buttonPanel.add(deleteButton);
        buttonPanel.add(addButton);
        buttonPanel.add(searchField);
        buttonPanel.add(searchButton);

        searcpanel.add(searchButton);
        searcpanel.add(searchField);
        searcpanel.add(displayButton);
        // Initialize table and model
        tableModel = new DefaultTableModel(new String[]{"First Name", "Last Name", "Phone", "Address"}, 0);
        contactsTable = new JTable(tableModel);
        JScrollPane scrollPane = new JScrollPane(contactsTable);

        // Add components to main panel
        contactPanel.add(scrollPane, BorderLayout.CENTER);  // Add the table in the center
        contactPanel.add(buttonPanel, BorderLayout.SOUTH);  // Add buttons at the bottom
        contactPanel.add(searcpanel,BorderLayout.NORTH);



        // Set content pane
        setContentPane(contactPanel);

        // Load contacts into table
        displayButton.addActionListener(new ActionListener() {
            @Override
            public void actionPerformed(ActionEvent e) {
                loadContactsFromFile();
            }
        });





        // Action listeners for buttons
        searchButton.addActionListener(new ActionListener() {
            @Override
            public void actionPerformed(ActionEvent e) {
                String query = searchField.getText().toLowerCase();
                searchContact(query);
            }
        });

        sortAscButton.addActionListener(new ActionListener() {
            @Override
            public void actionPerformed(ActionEvent e) {
                sortContacts(true);
            }
        });

        sortDscButton.addActionListener(new ActionListener() {
            @Override
            public void actionPerformed(ActionEvent e) {
                sortContacts(false);
            }
        });

        deleteButton.addActionListener(new ActionListener() {
            @Override
            public void actionPerformed(ActionEvent e) {
                int selectedRow = contactsTable.getSelectedRow();
                if (selectedRow != -1) {
                    contacts.remove(selectedRow);
                    tableModel.removeRow(selectedRow);
                } else {
                    JOptionPane.showMessageDialog(contactPanel, "Please select a contact to delete.");
                }
            }
        });

        addButton.addActionListener(new ActionListener() {
            @Override
            public void actionPerformed(ActionEvent e) {
                JFrame PhonebookFrame = new JFrame("Phonebook");
                Phonebook phonebook = new Phonebook();
                phonebook.setContentPane(phonebook.PhonebookPanel());
                phonebook.setVisible(true);
                frame.dispose();
            }
        });
    }

    private void loadContactsFromFile() {
        contacts.clear();  // Clear the existing contacts
        tableModel.setRowCount(0);  // Clear the table

        try (BufferedReader reader = new BufferedReader(new FileReader(FILE_NAME))) {
            String line;
            while ((line = reader.readLine()) != null) {
                String[] contact = line.split(",");
                if (contact.length == 4) {  // Ensure there are four fields
                    contacts.add(contact);  // Add to the ArrayList
                    tableModel.addRow(contact);  // Add to the table
                }
            }
        } catch (IOException e) {
            e.printStackTrace();
        }
    }
    private void saveContactsToFile() {
        try (BufferedWriter writer = new BufferedWriter(new FileWriter(FILE_NAME))) {
            for (String[] contact : contacts) {
                writer.write(contact[0] + "," + contact[1] + "," + contact[2] + "," + contact[3]);
                writer.newLine();
            }
        } catch (IOException e) {
            e.printStackTrace();
        }
    }


    private void searchContact(String query) {
        tableModel.setRowCount(0);  // Clear the table
        for (String[] contact : contacts) {
            if (contact[0].toLowerCase().contains(query) || contact[1].toLowerCase().contains(query) ||
                    contact[2].contains(query) || contact[3].toLowerCase().contains(query)) {
                tableModel.addRow(contact);
            }
        }
    }

    private void sortContacts(boolean ascending) {
        Collections.sort(contacts, new Comparator<String[]>() {
            @Override
            public int compare(String[] o1, String[] o2) {
                String fullName1 = o1[0] + " " + o1[1];  // Compare by full name
                String fullName2 = o2[0] + " " + o2[1];
                return ascending ? fullName1.compareTo(fullName2) : fullName2.compareTo(fullName1);
            }
        });
        loadContactsFromFile();  // Reload sorted contacts into the table
        saveContactsToFile();  // Reload sorted contacts into the table
    }
}
